export * from './avatar.component';
export * from './rating.component';
