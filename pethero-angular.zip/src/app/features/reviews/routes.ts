import { Routes } from '@angular/router';
import { ReviewsPage } from '@features/reviews/pages';

export const REVIEWS_ROUTES: Routes = [{ path: '', component: ReviewsPage }];
