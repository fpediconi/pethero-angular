/* Placeholder de diálogo de reseña */
