export interface Favorite {
  id: string;
  ownerId: string;
  guardianId: string;
  createdAt: string;
}

